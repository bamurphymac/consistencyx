//
//  LogInfo.m
//  mcinsight
//
//  Created by aa on 7/13/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "LogInfo.h"


@implementation LogInfo

@synthesize sid;
@synthesize data;
@synthesize direction;

@end
