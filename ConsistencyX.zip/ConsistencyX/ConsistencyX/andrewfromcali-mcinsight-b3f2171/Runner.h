//
//  Runner.h
//  mcinsight
//
//  Created by aa on 7/10/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Runner : NSObject {

}

@end
